CREATE TABLE "sanitisers" (
	"product_name "	TEXT,
	"active_ingredient"	TEXT,
	"alcohol-based"	TEXT,
	PRIMARY KEY("product_name ")
);