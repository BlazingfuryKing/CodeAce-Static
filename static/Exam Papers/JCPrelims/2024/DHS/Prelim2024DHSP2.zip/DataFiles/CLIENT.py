def decompress(compressed_list, byte_rep , bytes_pattern):
    #copy and paste your decompress function here
	
	
	
#main program

#type your client code here
