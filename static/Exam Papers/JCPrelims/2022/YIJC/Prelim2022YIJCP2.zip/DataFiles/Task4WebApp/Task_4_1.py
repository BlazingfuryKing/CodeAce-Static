from csv import *
from sqlite3 import *

#write program code to populate the Loan table with the data from LOAN.TXT


db.close()
