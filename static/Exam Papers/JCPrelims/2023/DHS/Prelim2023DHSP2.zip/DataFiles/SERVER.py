def decrypt(ciphertext):
    #copy and paste your decrypt function here
    
	
#main program

#type your server code here

