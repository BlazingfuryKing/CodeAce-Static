test_board = [
    ['r', 'r', 'd', 'e', 'd'],
    ['s', 'd', 'r', 'd', 't'],
    ['d', 'd', 'r', 's', 'd'],
    ['e', 'r', 't', 'r', 'r'],
    ['t', 'e', 'e', 's', 'd']]


class Begemed:
    pass
